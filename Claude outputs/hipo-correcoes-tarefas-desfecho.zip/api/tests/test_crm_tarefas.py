"""
HIPO — Testes do router /crm/tarefas.

As regras puras já estão em test_tarefa_regras.py. Aqui o foco é o que só
aparece com banco:

  * a corrente de follow-up (tarefa_anterior_id) sendo montada de verdade
  * conclusão e criação da próxima na MESMA transação
  * a contagem de abertas que alimenta o badge da aba
  * os CHECKs do banco como última linha de defesa
"""
import uuid
from datetime import datetime, timedelta, timezone

import pytest

from services import tarefa as regras
from tests.conftest import criar_usuario

# Todo desfecho exige o registro do fechamento — a tarefa que conta O QUE
# fechou o negócio, gravada já concluída na mesma transação. Constante aqui
# para os testes que apenas PRECISAM finalizar uma oportunidade não repetirem
# o payload; os testes da regra em si montam o seu próprio.
TAREFA_FIM = {"tipo": "reuniao", "titulo": "Reunião de fechamento"}

CNPJ_A = "11.222.333/0001-81"


# ── Helpers ──────────────────────────────────────────────────────────

def em(dias, hora=10):
    """
    Prazo a N dias de hoje, às `hora` — no FUSO DA OPERAÇÃO.

    O fuso aqui não é detalhe: `regras.situacao()` decide 'atrasada', 'hoje'
    e 'futura' pelo dia de calendário em America/Sao_Paulo, e o runner do CI
    roda em UTC. Ancorado em `now(timezone.utc)`, este helper devolvia o dia
    UTC — igual ao de Brasília durante quase todo o dia, mas DIFERENTE entre
    21h e meia-noite: `em(0)` caía no dia seguinte e virava 'futura',
    `em(-1)` virava 'hoje', e a suíte inteira de situações ficava vermelha
    sem ninguém ter mexido em nada. Aconteceu num run das 00:49 UTC.

    Ancorado no fuso da operação, o dia do prazo é o mesmo dia que a regra
    calcula, a qualquer hora do relógio. Mesmo cuidado do `carimbar` de
    test_tarefas_parceiro.py.
    """
    d = datetime.now(regras.FUSO_OPERACAO) + timedelta(days=dias)
    return d.replace(hour=hora, minute=0, second=0, microsecond=0).isoformat()


async def nova_conta(client, headers):
    resp = await client.post(
        "/crm/contas",
        json={"razao_social": "Metalurgica Alfa LTDA", "cnpj": CNPJ_A},
        headers=headers,
    )
    assert resp.status_code == 201, resp.text
    return resp.json()


async def nova_oportunidade(client, headers, conta_id):
    resp = await client.post(
        "/crm/oportunidades", json={"conta_id": conta_id}, headers=headers
    )
    assert resp.status_code == 201, resp.text
    return resp.json()


async def nova_tarefa(client, headers, oportunidade_id, usuario_id, **extra):
    corpo = {
        "oportunidade_id": oportunidade_id,
        "tipo": "ligacao",
        "titulo": "Ligar para o RH",
        "responsavel_id": usuario_id,
        "prazo": em(1),
    }
    corpo.update(extra)
    resp = await client.post("/crm/tarefas", json=corpo, headers=headers)
    assert resp.status_code == 201, resp.text
    return resp.json()


def proxima(usuario_id, **extra):
    corpo = {
        "tipo": "reuniao",
        "titulo": "Apresentar proposta",
        "responsavel_id": usuario_id,
        "prazo": em(7),
    }
    corpo.update(extra)
    return corpo


async def id_do_usuario(db_conn, email):
    """
    O helper criar_usuario do conftest devolve token e headers, não o id — e
    responsavel_id é obrigatório em toda tarefa.
    """
    return str(await db_conn.fetchval(
        "SELECT id FROM usuarios WHERE email = $1", email
    ))


@pytest.fixture
async def cenario(db_conn, client, usuario_adm):
    conta = await nova_conta(client, usuario_adm["headers"])
    opp = await nova_oportunidade(client, usuario_adm["headers"], conta["id"])
    return {
        "headers": usuario_adm["headers"],
        "usuario_id": await id_do_usuario(db_conn, usuario_adm["email"]),
        "conta": conta,
        "opp": opp,
    }


# ── Criação ──────────────────────────────────────────────────────────

class TestCriar:
    async def test_cria_com_contexto(self, db_conn, client, cenario):
        t = await nova_tarefa(
            client, cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        )
        assert t["oportunidade_numero"] == cenario["opp"]["numero"]
        assert t["conta_razao_social"] == "Metalurgica Alfa LTDA"
        assert t["tipo_rotulo"] == "Ligação"
        assert t["situacao"] == "futura"
        assert t["tarefa_anterior_id"] is None

    async def test_prazo_no_passado_nasce_atrasada(self, db_conn, client, cenario):
        """
        Nada impede registrar uma tarefa com prazo vencido — é assim que se
        lança o que já devia ter sido feito. A situação apenas conta a
        verdade.
        """
        t = await nova_tarefa(
            client, cenario["headers"], cenario["opp"]["id"],
            cenario["usuario_id"], prazo=em(-3),
        )
        assert t["situacao"] == "atrasada"

    async def test_titulo_so_de_espaco_e_422(self, db_conn, client, cenario):
        resp = await client.post(
            "/crm/tarefas",
            json={
                "oportunidade_id": cenario["opp"]["id"], "tipo": "ligacao",
                "titulo": "   ", "responsavel_id": cenario["usuario_id"],
                "prazo": em(1),
            },
            headers=cenario["headers"],
        )
        assert resp.status_code == 422

    async def test_tipo_desconhecido_e_422(self, db_conn, client, cenario):
        resp = await client.post(
            "/crm/tarefas",
            json={
                "oportunidade_id": cenario["opp"]["id"], "tipo": "cafezinho",
                "titulo": "X", "responsavel_id": cenario["usuario_id"],
                "prazo": em(1),
            },
            headers=cenario["headers"],
        )
        assert resp.status_code == 422

    async def test_oportunidade_inexistente_e_422(self, db_conn, client, cenario):
        resp = await client.post(
            "/crm/tarefas",
            json={
                "oportunidade_id": str(uuid.uuid4()), "tipo": "ligacao",
                "titulo": "X", "responsavel_id": cenario["usuario_id"],
                "prazo": em(1),
            },
            headers=cenario["headers"],
        )
        assert resp.status_code == 422
        assert "Oportunidade" in resp.json()["detail"]

    async def test_responsavel_inexistente_e_422(self, db_conn, client, cenario):
        resp = await client.post(
            "/crm/tarefas",
            json={
                "oportunidade_id": cenario["opp"]["id"], "tipo": "ligacao",
                "titulo": "X", "responsavel_id": str(uuid.uuid4()),
                "prazo": em(1),
            },
            headers=cenario["headers"],
        )
        assert resp.status_code == 422
        assert "Responsável" in resp.json()["detail"]


# ── Listagem ─────────────────────────────────────────────────────────

class TestListagem:
    async def test_passadas_em_aberto_e_futuras_na_mesma_lista(
        self, db_conn, client, cenario
    ):
        """O pedido original: histórico, aberto e futuro juntos."""
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        await nova_tarefa(client, h, o, u, prazo=em(-5), titulo="Atrasada")
        await nova_tarefa(client, h, o, u, prazo=em(0), titulo="De hoje")
        await nova_tarefa(client, h, o, u, prazo=em(5), titulo="Futura")

        body = (await client.get(
            f"/crm/tarefas?oportunidade_id={o}", headers=h
        )).json()
        assert body["total"] == 3
        assert [i["situacao"] for i in body["itens"]] == ["atrasada", "hoje", "futura"]

    async def test_ordena_atrasada_primeiro_e_concluida_por_ultimo(
        self, db_conn, client, cenario
    ):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        futura = await nova_tarefa(client, h, o, u, prazo=em(5), titulo="Futura")
        await nova_tarefa(client, h, o, u, prazo=em(-2), titulo="Atrasada")
        await client.post(
            f"/crm/tarefas/{futura['id']}/concluir",
            json={"proxima": proxima(u, prazo=em(9), titulo="Nova")},
            headers=h,
        )
        body = (await client.get(f"/crm/tarefas?oportunidade_id={o}", headers=h)).json()
        situacoes = [i["situacao"] for i in body["itens"]]
        assert situacoes[0] == "atrasada"
        assert situacoes[-1] == "concluida"

    async def test_ordem_cronologica_poe_o_futuro_no_topo(
        self, db_conn, client, cenario
    ):
        """
        Duas ordens porque sao duas perguntas: 'urgencia' e de quem vai
        TRABALHAR a lista, 'cronologico' e de quem vai LER a historia. A
        linha do tempo usa a segunda.
        """
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        await nova_tarefa(client, h, o, u, prazo=em(-10), titulo="Mais antiga")
        await nova_tarefa(client, h, o, u, prazo=em(20), titulo="Mais futura")
        await nova_tarefa(client, h, o, u, prazo=em(-1), titulo="Do meio")

        body = (await client.get(
            f"/crm/tarefas?oportunidade_id={o}&ordenar=cronologico", headers=h
        )).json()
        assert [i["titulo"] for i in body["itens"]] == [
            "Mais futura", "Do meio", "Mais antiga",
        ]

    async def test_urgencia_continua_sendo_o_padrao(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        await nova_tarefa(client, h, o, u, prazo=em(20), titulo="Futura")
        await nova_tarefa(client, h, o, u, prazo=em(-10), titulo="Atrasada")
        body = (await client.get(f"/crm/tarefas?oportunidade_id={o}", headers=h)).json()
        assert body["itens"][0]["titulo"] == "Atrasada"

    async def test_ordenar_invalido_e_422(self, db_conn, client, cenario):
        resp = await client.get(
            "/crm/tarefas?ordenar=alfabetica", headers=cenario["headers"]
        )
        assert resp.status_code == 422

    async def test_contadores_ignoram_fechadas(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        await nova_tarefa(client, h, o, u, prazo=em(-3), titulo="Atrasada")
        t = await nova_tarefa(client, h, o, u, prazo=em(2), titulo="Futura")
        await client.post(f"/crm/tarefas/{t['id']}/cancelar", json={}, headers=h)

        body = (await client.get(f"/crm/tarefas?oportunidade_id={o}", headers=h)).json()
        assert body["total"] == 2
        assert body["abertas"] == 1
        assert body["atrasadas"] == 1

    async def test_filtra_por_situacao(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        await nova_tarefa(client, h, o, u, prazo=em(-3))
        await nova_tarefa(client, h, o, u, prazo=em(3))
        body = (await client.get(
            f"/crm/tarefas?oportunidade_id={o}&situacao=atrasada", headers=h
        )).json()
        assert len(body["itens"]) == 1
        # Os contadores continuam sendo do conjunto INTEIRO, não do filtrado —
        # senão o cabeçalho mentiria sobre quanto falta.
        assert body["total"] == 2

    async def test_situacao_invalida_e_422(self, db_conn, client, cenario):
        resp = await client.get(
            "/crm/tarefas?situacao=amanha", headers=cenario["headers"]
        )
        assert resp.status_code == 422

    async def test_filtra_por_responsavel(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        await criar_usuario(db_conn, client, "EV", "outro@teste.com")
        outro_id = await id_do_usuario(db_conn, "outro@teste.com")
        await nova_tarefa(client, h, o, u)
        await nova_tarefa(client, h, o, outro_id, titulo="Do outro")
        body = (await client.get(
            f"/crm/tarefas?responsavel_id={outro_id}", headers=h
        )).json()
        assert [i["titulo"] for i in body["itens"]] == ["Do outro"]

    async def test_tarefa_de_outra_oportunidade_nao_vaza(self, db_conn, client, cenario):
        h, u = cenario["headers"], cenario["usuario_id"]
        outra = await nova_oportunidade(client, h, cenario["conta"]["id"])
        await nova_tarefa(client, h, cenario["opp"]["id"], u, titulo="Da primeira")
        await nova_tarefa(client, h, outra["id"], u, titulo="Da segunda")
        body = (await client.get(
            f"/crm/tarefas?oportunidade_id={outra['id']}", headers=h
        )).json()
        assert [i["titulo"] for i in body["itens"]] == ["Da segunda"]


# ── Kanban de gestao ─────────────────────────────────────────────────

class TestKanban:
    async def test_quatro_colunas_na_ordem(self, db_conn, client, cenario):
        colunas = (await client.get(
            "/crm/tarefas/kanban", headers=cenario["headers"]
        )).json()
        assert [c["situacao"] for c in colunas] == [
            "atrasada", "hoje", "futura", "concluida",
        ]
        assert [c["rotulo"] for c in colunas] == [
            "Atrasadas", "Para hoje", "Futuras", "Concluídas",
        ]

    async def test_rota_kanban_nao_e_lida_como_id(self, db_conn, client, cenario):
        """
        Regressao: com /{tarefa_id} declarado antes, 'kanban' virava id e a
        resposta era 422. Ja custou um 404 em /crm/dominio/usuarios.
        """
        resp = await client.get("/crm/tarefas/kanban", headers=cenario["headers"])
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    async def test_distribui_por_situacao(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        await nova_tarefa(client, h, o, u, prazo=em(-3), titulo="Atrasada")
        await nova_tarefa(client, h, o, u, prazo=em(0), titulo="De hoje")
        await nova_tarefa(client, h, o, u, prazo=em(4), titulo="Futura")

        colunas = (await client.get("/crm/tarefas/kanban", headers=h)).json()
        por = {c["situacao"]: c for c in colunas}
        assert por["atrasada"]["quantidade"] == 1
        assert por["hoje"]["quantidade"] == 1
        assert por["futura"]["quantidade"] == 1
        assert por["concluida"]["quantidade"] == 0

    async def test_junta_tarefas_de_oportunidades_diferentes(
        self, db_conn, client, cenario
    ):
        """O ponto da tela: gestao olha a carga, nao uma negociacao."""
        h, u = cenario["headers"], cenario["usuario_id"]
        outra = await nova_oportunidade(client, h, cenario["conta"]["id"])
        await nova_tarefa(client, h, cenario["opp"]["id"], u, prazo=em(-1), titulo="Da primeira")
        await nova_tarefa(client, h, outra["id"], u, prazo=em(-1), titulo="Da segunda")

        colunas = (await client.get("/crm/tarefas/kanban", headers=h)).json()
        atrasadas = next(c for c in colunas if c["situacao"] == "atrasada")
        assert atrasadas["quantidade"] == 2
        # E cada cartao carrega o contexto de qual negocio veio.
        assert {i["oportunidade_numero"] for i in atrasadas["itens"]} == {
            cenario["opp"]["numero"], outra["numero"],
        }

    async def test_cancelada_nao_tem_coluna(self, db_conn, client, cenario):
        """Ruido para quem esta gerindo carga; segue na linha do tempo."""
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u, prazo=em(-2))
        await client.post(f"/crm/tarefas/{t['id']}/cancelar", json={}, headers=h)

        colunas = (await client.get("/crm/tarefas/kanban", headers=h)).json()
        assert "cancelada" not in [c["situacao"] for c in colunas]
        assert sum(c["quantidade"] for c in colunas) == 0

    async def test_concluidas_e_janela_nao_historico_inteiro(
        self, db_conn, client, cenario
    ):
        """
        Aberto e estoque e cresce devagar; concluido e fluxo e cresce para
        sempre. Sem recorte a coluna vira arquivo morto.
        """
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        await client.post(
            f"/crm/tarefas/{t['id']}/concluir",
            json={"proxima": proxima(u)}, headers=h,
        )
        colunas = (await client.get("/crm/tarefas/kanban", headers=h)).json()
        assert next(c for c in colunas if c["situacao"] == "concluida")["quantidade"] == 1

        # Empurra a conclusao para 30 dias atras: sai da janela de 7 dias.
        await db_conn.execute(
            "UPDATE tarefas SET concluida_em = NOW() - interval '30 days'"
            " WHERE id = $1",
            uuid.UUID(t["id"]),
        )
        colunas = (await client.get("/crm/tarefas/kanban", headers=h)).json()
        assert next(c for c in colunas if c["situacao"] == "concluida")["quantidade"] == 0

        # Mas continua visivel se a janela for maior.
        colunas = (await client.get(
            "/crm/tarefas/kanban?dias_concluidas=60", headers=h
        )).json()
        assert next(c for c in colunas if c["situacao"] == "concluida")["quantidade"] == 1

    async def test_so_a_coluna_de_concluidas_e_somente_leitura(
        self, db_conn, client, cenario
    ):
        colunas = (await client.get(
            "/crm/tarefas/kanban", headers=cenario["headers"]
        )).json()
        leitura = [c["situacao"] for c in colunas if c["somente_leitura"]]
        assert leitura == ["concluida"]

    async def test_filtra_por_responsavel(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        await criar_usuario(db_conn, client, "EV", "outro@teste.com")
        outro_id = await id_do_usuario(db_conn, "outro@teste.com")
        await nova_tarefa(client, h, o, u, prazo=em(-1), titulo="Minha")
        await nova_tarefa(client, h, o, outro_id, prazo=em(-1), titulo="Do outro")

        colunas = (await client.get(
            f"/crm/tarefas/kanban?responsavel_id={outro_id}", headers=h
        )).json()
        atrasadas = next(c for c in colunas if c["situacao"] == "atrasada")
        assert [i["titulo"] for i in atrasadas["itens"]] == ["Do outro"]

    async def test_busca_por_empresa_numero_ou_titulo(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        await nova_tarefa(client, h, o, u, prazo=em(-1), titulo="Cobrar proposta")
        await nova_tarefa(client, h, o, u, prazo=em(-1), titulo="Mandar contrato")

        colunas = (await client.get(
            "/crm/tarefas/kanban?q=cobrar", headers=h
        )).json()
        atrasadas = next(c for c in colunas if c["situacao"] == "atrasada")
        assert [i["titulo"] for i in atrasadas["itens"]] == ["Cobrar proposta"]

        # A busca tambem pega pela empresa, que e como o gestor pensa.
        colunas = (await client.get(
            "/crm/tarefas/kanban?q=Metalurgica", headers=h
        )).json()
        assert next(c for c in colunas if c["situacao"] == "atrasada")["quantidade"] == 2

    async def test_atrasadas_vem_da_mais_antiga_para_a_mais_nova(
        self, db_conn, client, cenario
    ):
        """A ordem de atacar: quem esta parado ha mais tempo primeiro."""
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        await nova_tarefa(client, h, o, u, prazo=em(-2), titulo="Menos velha")
        await nova_tarefa(client, h, o, u, prazo=em(-20), titulo="Mais velha")

        colunas = (await client.get("/crm/tarefas/kanban", headers=h)).json()
        atrasadas = next(c for c in colunas if c["situacao"] == "atrasada")
        assert [i["titulo"] for i in atrasadas["itens"]] == ["Mais velha", "Menos velha"]

    async def test_concluidas_vem_da_mais_recente(self, db_conn, client, cenario):
        """Ali a pergunta e 'o que acabou de andar'."""
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        a = await nova_tarefa(client, h, o, u, prazo=em(-6), titulo="Velha")
        b = await nova_tarefa(client, h, o, u, prazo=em(-1), titulo="Recente")
        for t in (a, b):
            await client.post(
                f"/crm/tarefas/{t['id']}/concluir",
                json={"proxima": proxima(u)}, headers=h,
            )
        colunas = (await client.get("/crm/tarefas/kanban", headers=h)).json()
        concluidas = next(c for c in colunas if c["situacao"] == "concluida")
        assert [i["titulo"] for i in concluidas["itens"]] == ["Recente", "Velha"]

    async def test_quantidade_independe_do_limite_de_cartoes(
        self, db_conn, client, cenario
    ):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        for i in range(3):
            await nova_tarefa(client, h, o, u, prazo=em(-1 - i), titulo=f"T{i}")
        colunas = (await client.get(
            "/crm/tarefas/kanban?por_coluna=1", headers=h
        )).json()
        atrasadas = next(c for c in colunas if c["situacao"] == "atrasada")
        assert atrasadas["quantidade"] == 3
        assert len(atrasadas["itens"]) == 1


# ── Conclusão e a corrente ───────────────────────────────────────────

class TestConcluir:
    async def test_sem_proxima_com_oportunidade_ativa_e_recusado(
        self, db_conn, client, cenario
    ):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        resp = await client.post(
            f"/crm/tarefas/{t['id']}/concluir", json={"resultado": "Falei"}, headers=h
        )
        assert resp.status_code == 422
        assert "próxima tarefa" in resp.json()["detail"]

    async def test_com_proxima_conclui_e_agenda(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        resp = await client.post(
            f"/crm/tarefas/{t['id']}/concluir",
            json={"resultado": "Atendeu, pediu proposta", "proxima": proxima(u)},
            headers=h,
        )
        assert resp.status_code == 200
        # Devolve a CONCLUÍDA, não a nova: quem chamou está fechando um item.
        assert resp.json()["id"] == t["id"]
        assert resp.json()["situacao"] == "concluida"
        assert resp.json()["resultado"] == "Atendeu, pediu proposta"

        body = (await client.get(f"/crm/tarefas?oportunidade_id={o}", headers=h)).json()
        assert body["total"] == 2
        assert body["abertas"] == 1

    async def test_a_proxima_aponta_para_a_anterior(self, db_conn, client, cenario):
        """
        A corrente é o que permite reconstruir depois quanto tempo a
        negociação levou entre um contato e outro, sem inferir nada.
        """
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        await client.post(
            f"/crm/tarefas/{t['id']}/concluir",
            json={"proxima": proxima(u)}, headers=h,
        )
        body = (await client.get(f"/crm/tarefas?oportunidade_id={o}", headers=h)).json()
        nova = next(i for i in body["itens"] if i["id"] != t["id"])
        assert nova["tarefa_anterior_id"] == t["id"]

    async def test_oportunidade_finalizada_dispensa_a_proxima(
        self, db_conn, client, cenario
    ):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        await client.post(
            f"/crm/oportunidades/{o}/desfecho",
            json={"tarefa": TAREFA_FIM, "status": "conquistado"}, headers=h,
        )
        resp = await client.post(
            f"/crm/tarefas/{t['id']}/concluir",
            json={"resultado": "Assinou"}, headers=h,
        )
        assert resp.status_code == 200
        assert resp.json()["situacao"] == "concluida"

    async def test_suspensa_continua_exigindo(self, db_conn, client, cenario):
        """Pausa sem data para voltar é como oportunidade morre em silêncio."""
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        await client.patch(
            f"/crm/oportunidades/{o}/status",
            json={"status": "suspensa"}, headers=h,
        )
        resp = await client.post(
            f"/crm/tarefas/{t['id']}/concluir", json={}, headers=h
        )
        assert resp.status_code == 422

    async def test_proxima_com_responsavel_invalido_nao_conclui_nada(
        self, db_conn, client, cenario
    ):
        """
        Conclusão e próxima vivem na mesma transação. Se a próxima é
        impossível, a tarefa NÃO pode ficar concluída — senão a oportunidade
        ficaria sem próximo passo, que é o buraco que a regra tapa.
        """
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        resp = await client.post(
            f"/crm/tarefas/{t['id']}/concluir",
            json={"proxima": proxima(str(uuid.uuid4()))}, headers=h,
        )
        assert resp.status_code == 422
        depois = (await client.get(f"/crm/tarefas/{t['id']}", headers=h)).json()
        assert depois["situacao"] != "concluida"
        assert depois["concluida_em"] is None

    async def test_nao_conclui_duas_vezes(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        await client.post(
            f"/crm/tarefas/{t['id']}/concluir",
            json={"proxima": proxima(u)}, headers=h,
        )
        resp = await client.post(
            f"/crm/tarefas/{t['id']}/concluir",
            json={"proxima": proxima(u)}, headers=h,
        )
        assert resp.status_code == 422
        assert "já foi concluída" in resp.json()["detail"]

    async def test_resultado_em_branco_vira_nulo(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        body = (await client.post(
            f"/crm/tarefas/{t['id']}/concluir",
            json={"resultado": "   ", "proxima": proxima(u)}, headers=h,
        )).json()
        assert body["resultado"] is None


# ── Cancelamento ─────────────────────────────────────────────────────

class TestCancelar:
    async def test_cancela_sem_exigir_proxima(self, db_conn, client, cenario):
        """
        Cancelar é dizer que aquilo não deveria ter sido agendado, não que o
        negócio andou.
        """
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        body = (await client.post(
            f"/crm/tarefas/{t['id']}/cancelar",
            json={"motivo": "Agendei duplicado"}, headers=h,
        )).json()
        assert body["situacao"] == "cancelada"
        assert body["motivo_cancelamento"] == "Agendei duplicado"

    async def test_concluida_nao_cancela(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        await client.post(
            f"/crm/tarefas/{t['id']}/concluir",
            json={"proxima": proxima(u)}, headers=h,
        )
        resp = await client.post(f"/crm/tarefas/{t['id']}/cancelar", json={}, headers=h)
        assert resp.status_code == 422


# ── Edição ───────────────────────────────────────────────────────────

class TestEditar:
    async def test_edita_aberta(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        body = (await client.patch(
            f"/crm/tarefas/{t['id']}",
            json={"titulo": "Ligar de novo", "tipo": "whatsapp"}, headers=h,
        )).json()
        assert body["titulo"] == "Ligar de novo"
        assert body["tipo_rotulo"] == "WhatsApp"

    async def test_fechada_nao_edita(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        await client.post(
            f"/crm/tarefas/{t['id']}/concluir",
            json={"proxima": proxima(u)}, headers=h,
        )
        resp = await client.patch(
            f"/crm/tarefas/{t['id']}", json={"titulo": "Reescrevendo"}, headers=h
        )
        assert resp.status_code == 422
        assert "imutável" in resp.json()["detail"]

    async def test_patch_vazio_nao_quebra(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        resp = await client.patch(f"/crm/tarefas/{t['id']}", json={}, headers=h)
        assert resp.status_code == 200
        assert resp.json()["titulo"] == t["titulo"]

    async def test_muda_prazo_muda_a_situacao(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u, prazo=em(5))
        assert t["situacao"] == "futura"
        body = (await client.patch(
            f"/crm/tarefas/{t['id']}", json={"prazo": em(-2)}, headers=h
        )).json()
        assert body["situacao"] == "atrasada"

    async def test_inexistente_e_404(self, db_conn, client, cenario):
        resp = await client.patch(
            f"/crm/tarefas/{uuid.uuid4()}", json={"titulo": "X"},
            headers=cenario["headers"],
        )
        assert resp.status_code == 404


# ── Integração com a oportunidade ────────────────────────────────────

class TestBadgeDaAba:
    async def test_detalhe_conta_as_abertas(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        detalhe = (await client.get(f"/crm/oportunidades/{o}", headers=h)).json()
        assert detalhe["tarefas_abertas"] == 0

        await nova_tarefa(client, h, o, u)
        t = await nova_tarefa(client, h, o, u, prazo=em(3))
        await client.post(f"/crm/tarefas/{t['id']}/cancelar", json={}, headers=h)

        detalhe = (await client.get(f"/crm/oportunidades/{o}", headers=h)).json()
        assert detalhe["tarefas_abertas"] == 1

    async def test_apagar_oportunidade_leva_as_tarefas(self, db_conn, client, cenario):
        """ON DELETE CASCADE: tarefa órfã de oportunidade não faz sentido."""
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        await nova_tarefa(client, h, o, u)
        await db_conn.execute("DELETE FROM oportunidades WHERE id = $1", uuid.UUID(o))
        restam = await db_conn.fetchval(
            "SELECT count(*) FROM tarefas WHERE oportunidade_id = $1", uuid.UUID(o)
        )
        assert restam == 0


# ── CHECKs do banco, última linha de defesa ──────────────────────────

class TestChecksDoBanco:
    async def test_nao_aceita_concluida_e_cancelada(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        with pytest.raises(Exception, match="ck_tarefa_desfecho_unico"):
            await db_conn.execute(
                "UPDATE tarefas SET concluida_em = NOW(), cancelada_em = NOW()"
                " WHERE id = $1",
                uuid.UUID(t["id"]),
            )

    async def test_resultado_exige_conclusao(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        with pytest.raises(Exception, match="ck_tarefa_resultado"):
            await db_conn.execute(
                "UPDATE tarefas SET resultado = 'x' WHERE id = $1", uuid.UUID(t["id"])
            )

    async def test_tarefa_nao_e_a_propria_antecessora(self, db_conn, client, cenario):
        h, o, u = cenario["headers"], cenario["opp"]["id"], cenario["usuario_id"]
        t = await nova_tarefa(client, h, o, u)
        with pytest.raises(Exception, match="ck_tarefa_corrente"):
            await db_conn.execute(
                "UPDATE tarefas SET tarefa_anterior_id = id WHERE id = $1",
                uuid.UUID(t["id"]),
            )


# ── Schema x codigo ──────────────────────────────────────────────────

class TestSchemaBateComOCodigo:
    """
    Mesmo guarda que existe para as fases: o CI cria o banco a partir de
    api/schema.sql, não das migrations. Se a 004 mudar um CHECK e o
    schema.sql não acompanhar, isto falha com mensagem acionável em vez de
    dezenas de CheckViolationError.
    """

    async def test_o_banco_aceita_todos_os_tipos_do_codigo(self, db_conn):
        definicao = await db_conn.fetchval(
            "SELECT pg_get_constraintdef(oid) FROM pg_constraint"
            " WHERE conrelid = 'tarefas'::regclass AND conname = 'ck_tarefa_tipo'"
        )
        assert definicao, "constraint ck_tarefa_tipo nao existe no banco de teste"
        faltando = [t for t in regras.TIPOS if f"'{t}'" not in definicao]
        assert faltando == [], (
            f"ck_tarefa_tipo nao aceita {faltando}. "
            "Atualize api/schema.sql junto com a migration."
        )

    async def test_indice_das_abertas_existe(self, db_conn):
        """É o índice que a 'próxima tarefa' da Etapa 5 vai usar."""
        existe = await db_conn.fetchval(
            "SELECT 1 FROM pg_indexes"
            " WHERE tablename = 'tarefas' AND indexname = 'idx_tarefas_abertas'"
        )
        assert existe == 1


# ── Resumo de produção ───────────────────────────────────────────────
#
# "Quantas reuniões tivemos em agosto" era a pergunta que o HIPO não
# respondia: o dado existia desde a Sprint 5, mas só tarefa a tarefa, dentro
# do drilldown de cada oportunidade.
#
# Os carimbos são gravados direto no banco, e não pela rota de concluir,
# porque concluir usa NOW(). Sem escrever a data à mão não dá para montar um
# mês fechado, e um teste que só sabe testar "hoje" não trava justamente o
# que este endpoint promete: recortar um período que já passou.


async def concluir_em(db_conn, tarefa_id, quando: datetime):
    await db_conn.execute(
        "UPDATE tarefas SET concluida_em = $2 WHERE id = $1",
        uuid.UUID(tarefa_id), quando,
    )


async def cancelar_em(db_conn, tarefa_id, quando: datetime):
    await db_conn.execute(
        "UPDATE tarefas SET cancelada_em = $2 WHERE id = $1",
        uuid.UUID(tarefa_id), quando,
    )


def utc(dia, hora=14, mes=8, ano=2026):
    return datetime(ano, mes, dia, hora, tzinfo=timezone.utc)


def iso(dia, hora=14, mes=8, ano=2026):
    return utc(dia, hora, mes, ano).isoformat()


AGOSTO = {"de": "2026-08-01", "ate": "2026-08-31"}


def linha_tipo(corpo, tipo):
    return next(t for t in corpo["por_tipo"] if t["tipo"] == tipo)


class TestResumo:
    async def test_conta_as_reunioes_realizadas_no_mes(self, db_conn, client, cenario):
        """A pergunta que originou o endpoint, no caminho mais curto."""
        for dia in (5, 12, 27):
            t = await nova_tarefa(
                client, cenario["headers"], cenario["opp"]["id"],
                cenario["usuario_id"], tipo="reuniao", prazo=iso(dia),
            )
            await concluir_em(db_conn, t["id"], utc(dia, 16))

        resp = await client.get(
            "/crm/tarefas/resumo", params=AGOSTO, headers=cenario["headers"]
        )
        assert resp.status_code == 200, resp.text
        corpo = resp.json()
        assert corpo["realizadas"] == 3
        assert linha_tipo(corpo, "reuniao")["realizadas"] == 3

    async def test_ignora_o_que_caiu_fora_do_mes(self, db_conn, client, cenario):
        dentro = await nova_tarefa(
            client, cenario["headers"], cenario["opp"]["id"],
            cenario["usuario_id"], tipo="reuniao", prazo=iso(20),
        )
        fora = await nova_tarefa(
            client, cenario["headers"], cenario["opp"]["id"],
            cenario["usuario_id"], tipo="reuniao", prazo=iso(3, mes=9),
        )
        await concluir_em(db_conn, dentro["id"], utc(20, 16))
        await concluir_em(db_conn, fora["id"], utc(3, 16, mes=9))

        corpo = (await client.get(
            "/crm/tarefas/resumo", params=AGOSTO, headers=cenario["headers"]
        )).json()
        assert corpo["realizadas"] == 1

    async def test_o_ultimo_dia_do_mes_entra_inteiro(self, db_conn, client, cenario):
        """
        23:30 de 31/08 em Brasília é 02:30Z de 01/09. Um filtro montado em UTC
        jogaria essa reunião para setembro — e o número de agosto mudaria de
        valor conforme a hora em que alguém trabalhou.
        """
        t = await nova_tarefa(
            client, cenario["headers"], cenario["opp"]["id"],
            cenario["usuario_id"], tipo="reuniao", prazo=iso(31),
        )
        await concluir_em(db_conn, t["id"], datetime(2026, 9, 1, 2, 30, tzinfo=timezone.utc))

        corpo = (await client.get(
            "/crm/tarefas/resumo", params=AGOSTO, headers=cenario["headers"]
        )).json()
        assert corpo["realizadas"] == 1

    async def test_a_virada_do_mes_nao_entra(self, db_conn, client, cenario):
        """00:00 de 01/09 em Brasília (03:00Z) já é setembro."""
        t = await nova_tarefa(
            client, cenario["headers"], cenario["opp"]["id"],
            cenario["usuario_id"], tipo="reuniao", prazo=iso(31),
        )
        await concluir_em(db_conn, t["id"], datetime(2026, 9, 1, 3, tzinfo=timezone.utc))

        corpo = (await client.get(
            "/crm/tarefas/resumo", params=AGOSTO, headers=cenario["headers"]
        )).json()
        assert corpo["realizadas"] == 0

    async def test_realizada_e_agendada_sao_datas_diferentes(self, db_conn, client, cenario):
        """
        Reunião marcada para 28/08 e feita em 02/09: é de agosto na agenda e
        de setembro na produção. Um único filtro de data teria que escolher
        uma das duas e mentir na outra.
        """
        t = await nova_tarefa(
            client, cenario["headers"], cenario["opp"]["id"],
            cenario["usuario_id"], tipo="reuniao", prazo=iso(28),
        )
        await concluir_em(db_conn, t["id"], utc(2, 10, mes=9))

        agosto = (await client.get(
            "/crm/tarefas/resumo", params=AGOSTO, headers=cenario["headers"]
        )).json()
        assert agosto["agendadas"] == 1
        assert agosto["realizadas"] == 0

        setembro = (await client.get(
            "/crm/tarefas/resumo",
            params={"de": "2026-09-01", "ate": "2026-09-30"},
            headers=cenario["headers"],
        )).json()
        assert setembro["realizadas"] == 1
        assert setembro["agendadas"] == 0

    async def test_cancelada_nao_conta_como_realizada(self, db_conn, client, cenario):
        t = await nova_tarefa(
            client, cenario["headers"], cenario["opp"]["id"],
            cenario["usuario_id"], tipo="reuniao", prazo=iso(10),
        )
        await cancelar_em(db_conn, t["id"], utc(9, 11))

        corpo = (await client.get(
            "/crm/tarefas/resumo", params=AGOSTO, headers=cenario["headers"]
        )).json()
        assert corpo["realizadas"] == 0
        assert corpo["canceladas"] == 1
        assert linha_tipo(corpo, "reuniao")["canceladas"] == 1

    async def test_separa_por_tipo(self, db_conn, client, cenario):
        for tipo, dia in (("reuniao", 4), ("reuniao", 6), ("ligacao", 7)):
            t = await nova_tarefa(
                client, cenario["headers"], cenario["opp"]["id"],
                cenario["usuario_id"], tipo=tipo, prazo=iso(dia),
            )
            await concluir_em(db_conn, t["id"], utc(dia, 16))

        corpo = (await client.get(
            "/crm/tarefas/resumo", params=AGOSTO, headers=cenario["headers"]
        )).json()
        assert linha_tipo(corpo, "reuniao")["realizadas"] == 2
        assert linha_tipo(corpo, "ligacao")["realizadas"] == 1
        assert linha_tipo(corpo, "visita")["realizadas"] == 0

    async def test_devolve_sempre_os_sete_tipos_na_ordem_do_vocabulario(
        self, db_conn, client, cenario
    ):
        """
        Omitir o que deu zero faria a barra da tela trocar de ordem e de
        largura a cada mês. E o zero é informação: nenhuma visita em agosto é
        um fato sobre agosto.
        """
        corpo = (await client.get(
            "/crm/tarefas/resumo", params=AGOSTO, headers=cenario["headers"]
        )).json()
        assert [t["tipo"] for t in corpo["por_tipo"]] == list(regras.TIPOS)
        assert linha_tipo(corpo, "reuniao")["rotulo"] == "Reunião"

    async def test_quebra_por_responsavel(self, db_conn, client, cenario):
        outro = await criar_usuario(db_conn, client, "EV", "ev-resumo@teste.com")
        outro_id = await id_do_usuario(db_conn, outro["email"])

        for dono, dia in ((cenario["usuario_id"], 5), (cenario["usuario_id"], 6), (outro_id, 7)):
            t = await nova_tarefa(
                client, cenario["headers"], cenario["opp"]["id"], dono,
                tipo="reuniao", prazo=iso(dia),
            )
            await concluir_em(db_conn, t["id"], utc(dia, 16))

        corpo = (await client.get(
            "/crm/tarefas/resumo", params=AGOSTO, headers=cenario["headers"]
        )).json()
        # Mais produtivo primeiro: a lista existe para comparar carga.
        assert [p["realizadas"] for p in corpo["por_responsavel"]] == [2, 1]
        assert sum(p["realizadas"] for p in corpo["por_responsavel"]) == corpo["realizadas"]

    async def test_quem_nao_fez_nada_no_periodo_nao_aparece(self, db_conn, client, cenario):
        await criar_usuario(db_conn, client, "EV", "ocioso@teste.com")
        t = await nova_tarefa(
            client, cenario["headers"], cenario["opp"]["id"],
            cenario["usuario_id"], tipo="reuniao", prazo=iso(5),
        )
        await concluir_em(db_conn, t["id"], utc(5, 16))

        corpo = (await client.get(
            "/crm/tarefas/resumo", params=AGOSTO, headers=cenario["headers"]
        )).json()
        assert len(corpo["por_responsavel"]) == 1

    async def test_filtra_por_responsavel(self, db_conn, client, cenario):
        outro = await criar_usuario(db_conn, client, "EV", "ev-filtro@teste.com")
        outro_id = await id_do_usuario(db_conn, outro["email"])
        for dono, dia in ((cenario["usuario_id"], 5), (outro_id, 6)):
            t = await nova_tarefa(
                client, cenario["headers"], cenario["opp"]["id"], dono,
                tipo="reuniao", prazo=iso(dia),
            )
            await concluir_em(db_conn, t["id"], utc(dia, 16))

        corpo = (await client.get(
            "/crm/tarefas/resumo",
            params={**AGOSTO, "responsavel_id": outro_id},
            headers=cenario["headers"],
        )).json()
        assert corpo["realizadas"] == 1

    async def test_a_busca_da_barra_tambem_recorta_o_agregado(
        self, db_conn, client, cenario
    ):
        """
        Agregado que ignora o filtro da tela produz um número global ao lado
        de uma lista filtrada — duas respostas para a mesma pergunta.
        """
        t = await nova_tarefa(
            client, cenario["headers"], cenario["opp"]["id"],
            cenario["usuario_id"], tipo="reuniao", prazo=iso(5),
        )
        await concluir_em(db_conn, t["id"], utc(5, 16))

        achou = (await client.get(
            "/crm/tarefas/resumo",
            params={**AGOSTO, "q": "Metalurgica"},
            headers=cenario["headers"],
        )).json()
        assert achou["realizadas"] == 1

        vazio = (await client.get(
            "/crm/tarefas/resumo",
            params={**AGOSTO, "q": "Empresa Que Nao Existe"},
            headers=cenario["headers"],
        )).json()
        assert vazio["realizadas"] == 0

    async def test_sem_periodo_conta_a_historia_inteira(self, db_conn, client, cenario):
        for dia, mes in ((5, 8), (5, 9)):
            t = await nova_tarefa(
                client, cenario["headers"], cenario["opp"]["id"],
                cenario["usuario_id"], tipo="reuniao", prazo=iso(dia, mes=mes),
            )
            await concluir_em(db_conn, t["id"], utc(dia, 16, mes=mes))

        corpo = (await client.get(
            "/crm/tarefas/resumo", headers=cenario["headers"]
        )).json()
        assert corpo["realizadas"] == 2
        assert corpo["de"] is None and corpo["ate"] is None

    async def test_periodo_invertido_e_422(self, db_conn, client, cenario):
        resp = await client.get(
            "/crm/tarefas/resumo",
            params={"de": "2026-08-31", "ate": "2026-08-01"},
            headers=cenario["headers"],
        )
        assert resp.status_code == 422
        assert "depois" in resp.json()["detail"]

    async def test_resumo_nao_e_lido_como_id_de_tarefa(self, db_conn, client, cenario):
        """
        A rota precisa vir declarada antes de /{tarefa_id}. Com o wildcard
        primeiro, "resumo" vira id e a resposta é 422 — a mesma armadilha que
        já custou um 404 no kanban.
        """
        resp = await client.get("/crm/tarefas/resumo", headers=cenario["headers"])
        assert resp.status_code == 200

    async def test_tarefa_de_parceiro_entra_no_resumo(self, db_conn, client, usuario_adm):
        """
        Os JOINs do resumo são LEFT pelo mesmo motivo dos da listagem: com
        INNER, toda tarefa de parceiro sumiria da contagem em silêncio.
        """
        headers = usuario_adm["headers"]
        usuario_id = await id_do_usuario(db_conn, usuario_adm["email"])
        conta = await nova_conta(client, headers)
        await db_conn.execute(
            "UPDATE contas SET eh_finder = true WHERE id = $1",
            uuid.UUID(conta["id"]),
        )
        resp = await client.post(
            "/crm/tarefas",
            json={
                "conta_id": conta["id"], "tipo": "reuniao",
                "titulo": "Café com o contador", "responsavel_id": usuario_id,
                "prazo": iso(11),
            },
            headers=headers,
        )
        assert resp.status_code == 201, resp.text
        await concluir_em(db_conn, resp.json()["id"], utc(11, 16))

        corpo = (await client.get(
            "/crm/tarefas/resumo", params=AGOSTO, headers=headers
        )).json()
        assert corpo["realizadas"] == 1


class TestDrilldownDoResumo:
    """
    Clicar em "3 reuniões realizadas em agosto" tem que abrir exatamente
    aquelas três. O recorte é o mesmo dos dois lados; estes testes são o que
    impede os dois números de divergirem.
    """

    async def test_lista_as_mesmas_tarefas_que_o_resumo_contou(
        self, db_conn, client, cenario
    ):
        for dia in (5, 12, 27):
            t = await nova_tarefa(
                client, cenario["headers"], cenario["opp"]["id"],
                cenario["usuario_id"], tipo="reuniao", prazo=iso(dia),
            )
            await concluir_em(db_conn, t["id"], utc(dia, 16))
        outra = await nova_tarefa(
            client, cenario["headers"], cenario["opp"]["id"],
            cenario["usuario_id"], tipo="ligacao", prazo=iso(9),
        )
        await concluir_em(db_conn, outra["id"], utc(9, 16))

        params = {**AGOSTO, "tipo": "reuniao", "base": "conclusao"}
        lista = (await client.get(
            "/crm/tarefas", params=params, headers=cenario["headers"]
        )).json()
        resumo = (await client.get(
            "/crm/tarefas/resumo", params=AGOSTO, headers=cenario["headers"]
        )).json()

        assert lista["total"] == linha_tipo(resumo, "reuniao")["realizadas"] == 3
        assert all(i["tipo"] == "reuniao" for i in lista["itens"])

    async def test_base_prazo_e_base_conclusao_dao_listas_diferentes(
        self, db_conn, client, cenario
    ):
        t = await nova_tarefa(
            client, cenario["headers"], cenario["opp"]["id"],
            cenario["usuario_id"], tipo="reuniao", prazo=iso(28),
        )
        await concluir_em(db_conn, t["id"], utc(2, 10, mes=9))

        por_prazo = (await client.get(
            "/crm/tarefas", params={**AGOSTO, "base": "prazo"},
            headers=cenario["headers"],
        )).json()
        por_conclusao = (await client.get(
            "/crm/tarefas", params={**AGOSTO, "base": "conclusao"},
            headers=cenario["headers"],
        )).json()
        assert por_prazo["total"] == 1
        assert por_conclusao["total"] == 0

    async def test_base_desconhecida_e_422(self, db_conn, client, cenario):
        resp = await client.get(
            "/crm/tarefas", params={"base": "criacao"}, headers=cenario["headers"]
        )
        assert resp.status_code == 422

    async def test_tipo_desconhecido_no_filtro_e_422(self, db_conn, client, cenario):
        resp = await client.get(
            "/crm/tarefas", params={"tipo": "cafezinho"}, headers=cenario["headers"]
        )
        assert resp.status_code == 422

    async def test_periodo_invertido_na_listagem_e_422(self, db_conn, client, cenario):
        resp = await client.get(
            "/crm/tarefas",
            params={"de": "2026-08-31", "ate": "2026-08-01"},
            headers=cenario["headers"],
        )
        assert resp.status_code == 422

    async def test_busca_na_listagem(self, db_conn, client, cenario):
        await nova_tarefa(
            client, cenario["headers"], cenario["opp"]["id"],
            cenario["usuario_id"], titulo="Ligar para o RH", prazo=iso(5),
        )
        achou = (await client.get(
            "/crm/tarefas", params={"q": "RH"}, headers=cenario["headers"]
        )).json()
        assert achou["total"] == 1
        vazio = (await client.get(
            "/crm/tarefas", params={"q": "zzzz"}, headers=cenario["headers"]
        )).json()
        assert vazio["total"] == 0

    async def test_os_filtros_novos_nao_deslocam_os_antigos(
        self, db_conn, client, cenario
    ):
        """
        Numeração de parâmetro posicional é o tipo de erro que não levanta
        exceção: devolve a linha errada. Este teste combina TODOS os filtros
        de uma vez, que é quando o deslocamento apareceria.
        """
        alvo = await nova_tarefa(
            client, cenario["headers"], cenario["opp"]["id"],
            cenario["usuario_id"], tipo="reuniao",
            titulo="Reuniao de fechamento", prazo=iso(15),
        )
        await concluir_em(db_conn, alvo["id"], utc(15, 16))
        ruido = await nova_tarefa(
            client, cenario["headers"], cenario["opp"]["id"],
            cenario["usuario_id"], tipo="ligacao",
            titulo="Outra coisa", prazo=iso(15),
        )
        await concluir_em(db_conn, ruido["id"], utc(15, 17))

        corpo = (await client.get(
            "/crm/tarefas",
            params={
                "oportunidade_id": cenario["opp"]["id"],
                "responsavel_id": cenario["usuario_id"],
                "tipo": "reuniao",
                "de": "2026-08-01", "ate": "2026-08-31",
                "base": "conclusao",
                "q": "fechamento",
                "situacao": ["concluida"],
            },
            headers=cenario["headers"],
        )).json()
        assert [i["id"] for i in corpo["itens"]] == [alvo["id"]]
